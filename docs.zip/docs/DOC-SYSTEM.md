# 문서 체계 — CodeBomb LMS (DOC-SYSTEM)

> 이 프로젝트 문서들이 **어디에 무엇을 담는지(owns-what)**, 도메인 `README`를 어떻게 **불변 핵심만 남겨 슬림하게** 유지하는지의 **단일 참조**다.
> `AGENTS.md`는 이 파일로 포인터만 둔다. "왜 이렇게 정했나"의 결정·이유는 [`docs/adr/`](adr/) (특히 [ADR-0001](adr/0001-ai-docs-system.md)).

## 문서 종류·배치

| 문서 | 경로 | 구분 |
|------|------|------|
| 프로젝트 규칙 (메인) | `AGENTS.md` (루트 `CLAUDE.md`는 얇은 포인터) | 공용·커밋 (PL 소유) |
| 문서 체계 (이 파일) | `docs/DOC-SYSTEM.md` | 공용·커밋 (PL 소유) |
| 교차 도메인 경계·관계 | `CONTEXT-MAP.md` (루트) | 공용·커밋 (PL 소유) |
| 팀 결정·이유 | `docs/adr/` | 공용·커밋 (PL 소유) |
| 팀 규약(에러코드 등) | `docs/CONVENTION.md` | 공용·커밋 |
| 커밋·PR 양식·실행 | git 서브에이전트 `.claude/agents/` + `.github/pull_request_template.md` | 공용·커밋 |
| AI 응답 형식 | `docs/response-style.md` | 공용·커밋 |
| 도메인 불변 핵심(역할·용어) | `src/.../<도메인>/README.md` | 공용·커밋 (오너) |
| 개인 진행상황·도메인 상세 | `.ai/local/` | 개인·git-ignore |

> `.ai/local/` 은 통째로 git-ignore. 각자 작업메모(세컨드브레인 — STATE·API·WORKLOG·도메인 상세)를 여기에 둔다. 커밋되지 않는다.

## owns-what (한 사실은 한 곳에만)

새 정보가 생기면 **성질로 판단**해 한 곳에만 배치한다:

| 성질 | 어디에 | 규칙 / README에? |
|------|--------|------------------|
| **가변** (패키지 트리, 서비스·API 목록, 구현 상세) | **아무 데도 안 적음** (코드/Swagger) | README ❌ — 매번 코드/Swagger를 봄 |
| **불변 핵심** (도메인 역할, 용어/모델) | `<도메인>/README.md` | README ✅ — 바뀌면 덮어씀 |
| **교차 도메인** (경계·누가 누구를 호출/이벤트) | `CONTEXT-MAP.md` | README ❌ 링크만 — 단일 소스 |
| **결정·이유** (되돌리기 어렵고 대안이 있던 선택) | `docs/adr/` | README ❌ — append-only, 바뀌면 새 ADR로 supersede |
| **도메인 깊은 설명·작업맥락·핵심 흐름** | `.ai/local/` (개인·git-ignore) | README ❌ — 오너 개인 책임 |

> 판단: "단어/정의"면 README·CONTEXT-MAP, "왜 그렇게 했나"면 ADR, "자주 바뀌는 구조"면 코드(안 적음).

---

# 도메인 README 슬림화 가이드 (오너용)

> 대상: 각 도메인 오너. 자기 도메인 `README.md`를 **불변 핵심만** 남기고 줄이는 작업.
> 근거: 위 owns-what + [`CONTEXT-MAP.md`](CONTEXT-MAP.md). 본보기: [`chatbot/README.md`](../src/main/java/com/wanted/codebombalms/chatbot/README.md) (28줄).

**왜 슬림화하나** — README에 패키지 구조·서비스 목록·API 표·흐름을 적으면 코드가 바뀔 때마다 같이 썩는다(드리프트). 그래서 위 owns-what 표대로 성질별로 나눈다.

## 슬림 README = 3섹션만

```markdown
# {도메인} Domain

{한두 줄 소개}

## 주요 역할
- 이 도메인이 책임지는 것 (불변, 동사 위주)

## 주요 모델 (용어)
| 모델 | 설명 |
| --- | --- |
| `Xxx` | 한 줄 정의 |

## 경계
다른 도메인과의 연동은 루트 `CONTEXT-MAP.md`를 단일 소스로 본다.
```

> 끝에 한 줄: "패키지 구조·서비스·API는 코드/Swagger를 본다. 깊은 설명은 오너 `.ai/local/`."

## 잘라낼 것 → 어디로

| README의 이 섹션 | 처리 |
| --- | --- |
| `## 패키지 구조` (트리) | **삭제** (코드가 진실) |
| `## 주요 서비스` (서비스 표) | **삭제** (코드/Swagger) |
| `## API 목록` (엔드포인트 표) | **삭제** (Swagger가 진실, 자주 바뀜) |
| `## 핵심 흐름` (시퀀스 설명) | **`.ai/local/`로 이동** (작업맥락) |
| `## 다른 도메인과의 연동` (연동 표) | **삭제하고 `## 경계` 한 줄로** (CONTEXT-MAP이 단일 소스) |
| `## 주요 역할` | 유지 (단, 동사 위주 불변만) |
| `## 주요 모델` | 유지 (용어집. CONTEXT-MAP 용어와 일치시킬 것) |

## 단계

1. 위 표대로 패키지구조/서비스/API 섹션 **삭제**.
2. `핵심 흐름`이 아까우면 도메인 폴더 밖 개인 `.ai/local/`로 옮긴다(커밋 안 됨).
3. `다른 도메인과의 연동` 표 → `## 경계` 한 줄로 교체. 네 도메인의 실제 엣지가 [`CONTEXT-MAP.md`](CONTEXT-MAP.md)에 맞는지 확인하고, 틀리면 PL(또는 PR)로 교정 요청.
4. `주요 모델` 용어가 CONTEXT-MAP·이웃 도메인과 같은 단어인지 확인(같은 개념 다른 이름 금지).
5. 슬림 후 20~30줄 내외면 정상. chatbot(28줄) 기준.

## 본보기 비교

- **After(목표)**: [`chatbot/README.md`](../src/main/java/com/wanted/codebombalms/chatbot/README.md) — 28줄, 3섹션.
- **Before(전형적 비대)**: 현재 `course/README.md`(113줄)는 패키지구조·서비스표·API 13행·흐름 4개·연동표를 다 갖고 있다. 이 중 **소개·주요역할·주요모델만 남기면 약 30줄**.

## 검증 체크리스트

- [ ] 패키지 구조 트리 없음
- [ ] 서비스 목록 표 없음
- [ ] API 엔드포인트 표 없음
- [ ] 연동 내용은 `## 경계` 한 줄(CONTEXT-MAP 참조)뿐
- [ ] `주요 모델` 용어가 CONTEXT-MAP 및 이웃 도메인과 일치
- [ ] 도메인 상세·흐름은 `.ai/local/`에 있음(커밋 X)

## 현황 (줄수)

> ⚠️ **transient** — 슬림화 마이그레이션 추적용. 전 도메인 슬림 완료되면 이 표는 삭제한다.

| 도메인 | 줄수 | | 도메인 | 줄수 |
| --- | --- | --- | --- | --- |
| chatbot ✅ | 28 | | learning | 85 |
| ranking | 46 | | auth | 88 |
| reward | 49 | | admin | 92 |
| global | 56 | | course | 113 |
| badge | 58 | | problems | 132 |
| enrollment | 62 | | | |
| lecture | 64 | | | |
| user | 70 | | | |
| submission | 76 | | | |

> 오너 작업분은 CODEOWNERS에 따라 PL이 머지한다. 질문은 PL(suerovr).
