# CI/CD 배포 워크플로 컨벤션

> ⚠️ **현재 방식 변경됨(2026-06-24):** 워크플로 4종 모두 **GitHub OIDC(키리스) + S3 + SSM `send-command`** 로 전환됨(`appleboy/ssh-action`·`scp-action`·`AWS_ACCESS_KEY_ID/SECRET`·`EC2_SSH_*` 폐기). 아래 `appleboy`/SSH Secrets 표준은 **초기 방식 기록(학습용 보존)** 으로 현재와 다르다. 현재 패턴은 각 레포 `.github/workflows/deploy.yml` + [`../deploy/ssm-vs-ssh.md`](../../.ai/deploy/ssm-vs-ssh.md) 참조.

EC2 배포용 GitHub Actions 워크플로(`.github/workflows/deploy.yml`)를 작성할 때 **반드시 지킬 표준**.
프론트(①)·챗봇(④)·Spring(②) 등 ECR+EC2 배포 워크플로 공통 적용.

> 배경: 단순히 `build → push → ssh up`만 짜면 보안·안정성 구멍이 생긴다(CodeRabbit/zizmor 지적 다수). 아래는 그중 **실제로 적용할 가치가 있는 것만** 추린 표준이다.

---

## 1. 필수 항목 (모든 deploy 워크플로)

### 1-1. 동시 배포 차단 — `concurrency`
연속 push·중복 dispatch로 배포가 겹치면 EC2에서 race condition 발생.
```yaml
concurrency:
  group: deploy-<서비스>-${{ github.ref }}
  cancel-in-progress: false   # 진행 중 배포는 끊지 않고 큐잉 (배포 중단이 더 위험)
```

### 1-2. 최소 권한 — `permissions`
`GITHUB_TOKEN` 기본값은 write. 배포는 읽기만 필요.
```yaml
jobs:
  deploy:
    permissions:
      contents: read
```

### 1-3. 토큰 잔존 방지 — checkout
```yaml
- uses: actions/checkout@v4
  with:
    persist-credentials: false
```

### 1-4. 스크립트 실패 시 즉시 중단 — `set -e`
실패해도 다음 명령이 진행되면 깨진 이미지가 배포된다.
- **runner의 `run:` (bash)**: `set -euo pipefail`
- **원격 ssh 스크립트(appleboy/ssh-action, 셸이 sh일 수 있음)**: `set -e` (pipefail/-u는 bash 전용이라 이식성 위해 제외)

### 1-5. 변수 인젝션 방지 — `${{ }}`를 run에 직접 박지 말 것
`${{ vars.X }}`/`${{ github.* }}`를 `run:` 명령줄에 직접 쓰면 특수문자가 셸로 해석될 수 있다.
```yaml
env:
  API_URL: ${{ vars.NEXT_PUBLIC_API_URL }}
run: |
  docker build --build-arg NEXT_PUBLIC_API_URL="$API_URL" ...   # env 경유 + 따옴표
```

### 1-6. 기동 후 헬스 체크 (필수)
`docker compose up` 성공 ≠ 앱 정상. 반드시 응답 확인 후 종료.
```bash
for i in $(seq 1 30); do            # {1..30}은 bashism → sh 호환 위해 seq
  if curl -fs -o /dev/null http://localhost:<PORT>/<health>; then break; fi
  if [ "$i" -eq 30 ]; then docker compose logs --tail 50; exit 1; fi
  sleep 2
done
```
- 자체 헬스 엔드포인트(예: 챗봇 `/health`)가 있으면 **`curl -f`로 엄격하게**.
- 외부 의존(예: 백엔드 미배포 상태의 프론트)으로 5xx가 날 수 있으면 **`curl -s`(–f 없이)**로 "응답만 확인" → 의존 붙은 뒤 `-f`로 강화.

---

## 2. 빌드 전 검증 (앱 종류별)

CI에서 빌드 전에 **있는 검증 스크립트만** 실행. 없는 스크립트를 넣으면 워크플로가 깨진다 → `package.json`/도구 설정 먼저 확인.

| 앱 | 검증 |
|---|---|
| 프론트(Next.js) | `npm ci` → `npm run lint`. 타입검사는 Docker의 `next build`가 수행 |
| 챗봇(Python) | (선택) `pip install` → `ruff`/`pytest`. **외부 키 필요한 테스트는 CI에서 제외** |

> 원칙: **Dockerfile이 이미 하는 일(빌드)을 runner에서 중복하지 말 것.** lint/타입/테스트처럼 Docker가 안 하는 것만 앞단에 추가.

### 점진 도입 (기존 코드에 위반이 쌓여있을 때)
이미 진행 중인 프로젝트에 lint를 처음 넣으면 **기존 위반으로 배포가 막힌다.** 이때:
1. 해당 검증 스텝에 `continue-on-error: true`를 붙여 **비차단(결과는 보이되 배포는 통과)**으로 시작.
2. 별도 작업으로 기존 위반을 정리.
3. 정리 끝나면 `continue-on-error` 제거해 **차단(blocking)**으로 승격.

> 배포 작업과 무관한 기존 코드 빚 때문에 배포를 막지 않는다. 단, 비차단은 **임시 상태**임을 주석으로 남긴다.

---

## 3. 적용하지 않는 것 (이유 명시)

CodeRabbit/zizmor가 제안해도 **부트캠프 맥락에선 거르는** 항목:

| 제안 | 거르는 이유 |
|---|---|
| **action을 커밋 SHA로 핀 고정** | 가독성·유지보수성 저하 대비 이득 작음(공급망 공격 표적 아님). 태그(`@v4`) 유지. CodeRabbit도 "trivial/poor tradeoff"로 분류 |
| 없는 `npm run type-check`/`npm test` 추가 | 스크립트 미존재 → 워크플로 실패. 타입검사는 `next build`로 충분 |
| runner `run`에 별도 `npm run build` | Dockerfile의 `next build`와 **중복**(빌드 2회) |

> 보안 강화가 무의미하단 뜻이 아니라, **운영 진입 시 재검토** 대상이라는 의미. 그때 SHA 핀·permissions 세분화 등 다시 본다.

---

## 4. 표준 골격 (복사용)

```yaml
name: Deploy <서비스> (EC2)
on:
  push:
    branches: [main]
  workflow_dispatch:

concurrency:
  group: deploy-<서비스>-${{ github.ref }}
  cancel-in-progress: false

jobs:
  deploy:
    runs-on: ubuntu-latest
    permissions:
      contents: read
    steps:
      - uses: actions/checkout@v4
        with: { persist-credentials: false }
      # (프론트) setup-node → npm ci → npm run lint
      - uses: aws-actions/configure-aws-credentials@v4
        with: { aws-access-key-id: ..., aws-secret-access-key: ..., aws-region: ap-northeast-2 }
      - id: ecr
        uses: aws-actions/amazon-ecr-login@v2
      - name: build & push
        env: { REGISTRY: ..., REPO: ..., TAG: ${{ github.sha }} }
        run: |
          set -euo pipefail
          docker build -t "$REGISTRY/$REPO:$TAG" -t "$REGISTRY/$REPO:latest" .
          docker push "$REGISTRY/$REPO:$TAG" && docker push "$REGISTRY/$REPO:latest"
      - uses: appleboy/scp-action@v0.1.7      # deploy/** → /opt/<서비스>
      - uses: appleboy/ssh-action@v1.0.3      # set -e → login → pull → up → 헬스체크 → prune
```

---

## 5. 시크릿 / 변수 분리 (재확인)

| 종류 | 위치 | 예 |
|---|---|---|
| 배포용(파이프라인이 씀) | **GitHub Secrets** | `AWS_ACCESS_KEY_ID/SECRET`, `*_EC2_HOST`, `EC2_SSH_USER`, `EC2_SSH_KEY` |
| 앱 런타임 비밀값 | **EC2 `/opt/<서비스>/.env`** | `GEMINI_API_KEY`, `DB_*` |
| 비밀 아닌 빌드 설정 | **GitHub Variables** | `NEXT_PUBLIC_API_URL` |

> 상세는 `docs/deploy/chatbot-deploy.md` §4 참조.
